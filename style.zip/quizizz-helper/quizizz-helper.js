document.addEventListener('DOMContentLoaded', () => {
    const pdfFileInput = document.getElementById('pdfFile');
    const fileDropArea = document.querySelector('.file-drop-area');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const outputText = document.getElementById('outputText');
    const copyButton = document.getElementById('copyButton');
    const loader = document.getElementById('loader');
    const errorMessage = document.getElementById('error-message');

    // --- File Drop Area Logic ---
    fileDropArea.addEventListener('dragover', (event) => {
        event.preventDefault();
        fileDropArea.classList.add('dragover');
    });

    fileDropArea.addEventListener('dragleave', () => {
        fileDropArea.classList.remove('dragover');
    });

    fileDropArea.addEventListener('drop', (event) => {
        event.preventDefault();
        fileDropArea.classList.remove('dragover');
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            if (files[0].type === "application/pdf") {
                pdfFileInput.files = files; // Assign dropped file to input
                handleFile(files[0]);
            } else {
                showError("Please drop a PDF file.");
                resetUI();
            }
        }
    });
    
    // Trigger file input click when label is clicked
    fileDropArea.addEventListener('click', (event) => {
        if (event.target.classList.contains('file-input-label') || event.target.parentElement.classList.contains('file-input-label')) {
            // Let the label's default action trigger the input
        } else if (event.target !== pdfFileInput) { // Avoid re-triggering if input itself is somehow clicked
             pdfFileInput.click();
        }
    });

    pdfFileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            handleFile(file);
        } else {
            resetUI();
        }
    });

    function handleFile(file) {
        if (file.type !== "application/pdf") {
            showError("Invalid file type. Please upload a PDF.");
            resetUI();
            return;
        }
        fileNameDisplay.textContent = `Selected: ${file.name}`;
        outputText.value = ''; // Clear previous output
        copyButton.style.display = 'none';
        hideError();
        extractTextFromPdf(file);
    }
    
    function resetUI() {
        fileNameDisplay.textContent = "No file selected";
        pdfFileInput.value = ''; // Clear the file input
        outputText.value = '';
        copyButton.style.display = 'none';
        hideError();
    }

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
    }

    function hideError() {
        errorMessage.style.display = 'none';
    }

    async function extractTextFromPdf(file) {
        loader.style.display = 'block';
        outputText.placeholder = "Processing your PDF... please wait.";
        hideError();

        const reader = new FileReader();
        reader.onload = async (e) => {
            const typedarray = new Uint8Array(e.target.result);
            try {
                const pdf = await pdfjsLib.getDocument({ data: typedarray }).promise;
                let fullText = '';

                for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const textContent = await page.getTextContent();
                    textContent.items.forEach(item => {
                        fullText += item.str + ' '; // Add space between text items
                    });
                    fullText += '\n'; // Newline after each page's content
                }
                
                processTextForQuizizz(fullText);

            } catch (error) {
                console.error("Error parsing PDF:", error);
                showError("Could not process the PDF. It might be corrupted, encrypted, or image-based. Ensure it has selectable text.");
                outputText.placeholder = "Error processing PDF. Please try another file.";
            } finally {
                loader.style.display = 'none';
            }
        };
        reader.onerror = () => {
            console.error("File reading error");
            showError("Error reading the file.");
            loader.style.display = 'none';
            outputText.placeholder = "Error reading file.";
        };
        reader.readAsArrayBuffer(file);
    }

    function processTextForQuizizz(rawText) {
        // 1. Remove symbols: *, #, _
        let cleanedText = rawText.replace(/[*#_]/g, '');

        // 2. Normalize whitespace (multiple spaces/newlines to one)
        cleanedText = cleanedText.replace(/\s\s+/g, ' ').trim();
        
        // 3. Split into potential points (sentences or lines)
        //    This is a heuristic. Might need refinement based on typical PDF structures.
        //    Let's try splitting by periods followed by a space or newline,
        //    question marks, exclamation marks, and newlines if they seem significant.
        const potentialPoints = cleanedText.split(/(?<=[.?!])\s+|\n+/);

        let quizizzPoints = [];
        potentialPoints.forEach(point => {
            let trimmedPoint = point.trim();
            
            // Remove leading list-like markers (e.g., "1.", "a)", "- ")
            trimmedPoint = trimmedPoint.replace(/^(\d+\.|[a-zA-Z]\)|\-\s*)/, '').trim();

            // Basic filter: not too short, not too long.
            // Quizizz AI works best with concise statements.
            // Max length for a Quizizz question/answer is typically around 100-200 chars.
            // Let's aim for points under ~150 characters.
            if (trimmedPoint.length > 5 && trimmedPoint.length < 200) { 
                // Further ensure no unwanted characters remain if any slip through.
                // This regex removes any character that is NOT a letter, number, common punctuation (,.?!'-), or space.
                // It helps ensure plain text.
                trimmedPoint = trimmedPoint.replace(/[^\w\s,.?!'"()-]/g, ''); 
                quizizzPoints.push(trimmedPoint);
            }
        });

        if (quizizzPoints.length > 0) {
            outputText.value = quizizzPoints.join('\n'); // Each point on a new line
            copyButton.style.display = 'block';
            outputText.placeholder = "Your extracted points will appear here...";
        } else {
            outputText.value = '';
            outputText.placeholder = "No suitable points found. Try a different PDF or check its content.";
            showError("No suitable points extracted. The PDF might have very short text, non-standard formatting, or mostly images.");
            copyButton.style.display = 'none';
        }
    }

    copyButton.addEventListener('click', () => {
        outputText.select();
        outputText.setSelectionRange(0, 99999); // For mobile devices

        try {
            document.execCommand('copy');
            // Give feedback (optional, could be a small toast message)
            const originalText = copyButton.textContent;
            copyButton.textContent = 'Copied!';
            setTimeout(() => {
                copyButton.textContent = originalText;
            }, 1500);
        } catch (err) {
            console.error('Failed to copy text: ', err);
            alert('Failed to copy. Please manually select and copy the text.');
        }
    });
});